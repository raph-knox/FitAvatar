document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("avatarForm");
    const avatarContainer = document.getElementById("generatedAvatar");
    const avatarHeading = document.getElementById("avatarHeading");

    // Function to hide the loading spinner and show the iframe
    window.hideLoadingSpinner = function () {
        const loadingSpinner = document.getElementById("loadingSpinner");
        const iframe = document.getElementById("readyPlayerMeIframe");

        // Hide the spinner
        loadingSpinner.style.display = "none";

        // Show the iframe
        iframe.style.display = "block";
    };

    // Handle form submission
    form.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent form submission

        // Capture user input
        const avatarName = document.getElementById("avatarName").value.trim();
        const picture = document.getElementById("picture").files[0];
        const gender = document.querySelector('input[name="gender"]:checked').value;
        const age = document.getElementById("age").value;
        const height = document.getElementById("height").value;
        const weight = document.getElementById("weight").value;
        const capSize = document.getElementById("capSize").value;
        const shoeSize = document.getElementById("shoeSize").value;
        const extraInfo = document.getElementById("extraInfo").value;

        // Validate inputs
        if (!avatarName || !picture || !height || !weight) {
            alert("Please fill in all required fields and upload a picture.");
            return;
        }

        // Store user input (e.g., in localStorage or send to a server)
        const userInput = {
            avatarName,
            gender,
            age,
            height,
            weight,
            capSize,
            shoeSize,
            extraInfo,
        };
        localStorage.setItem("userInput", JSON.stringify(userInput));
        console.log("User input stored:", userInput);

        // Display a message (optional)
        alert("Your input has been saved. Continue creating your avatar.");
    });

    // Listen for messages from the ReadyPlayerMe iframe
    window.addEventListener("message", function (event) {
        if (event.data.type === "AVATAR_EXPORTED") {
            const avatarUrl = event.data.url; // URL of the generated avatar (GLB file)
            console.log("Avatar URL:", avatarUrl);

            // Retrieve user input
            const userInput = JSON.parse(localStorage.getItem("userInput"));
            console.log("User input retrieved:", userInput);

            // Display the avatar and user input
            avatarHeading.textContent = "Your Avatar";
            avatarContainer.innerHTML = `
                <p style="color: green;">Avatar generated successfully!</p>
                <p>Download your avatar: <a href="${avatarUrl}" target="_blank">Download Avatar</a></p>
                <iframe src="${avatarUrl}" width="100%" height="500px" style="border: 2px solid #ff0000; border-radius: 10px;"></iframe>
                <div style="margin-top: 20px; text-align: left;">
                    <h3>Your Details</h3>
                    <p><strong>Name:</strong> ${userInput.avatarName}</p>
                    <p><strong>Gender:</strong> ${userInput.gender}</p>
                    <p><strong>Age:</strong> ${userInput.age}</p>
                    <p><strong>Height:</strong> ${userInput.height} cm</p>
                    <p><strong>Weight:</strong> ${userInput.weight} kg</p>
                    <p><strong>Cap Size:</strong> ${userInput.capSize}</p>
                    <p><strong>Shoe Size:</strong> ${userInput.shoeSize}</p>
                    <p><strong>Extra Info:</strong> ${userInput.extraInfo}</p>
                </div>
            `;
        }
    });
});