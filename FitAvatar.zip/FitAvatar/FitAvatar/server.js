const express = require('express');
const axios = require('axios');
const cors = require('cors'); // Add CORS support

const app = express();
app.use(cors()); // Enable CORS
app.use(express.json());

// Replace with your Stable Diffusion WebUI URL
const STABLE_DIFFUSION_URL = "http://localhost:7860";

app.post('/generate-avatar', async (req, res) => {
    const prompt = req.body.prompt;

    try {
        const response = await axios.post(
            `${STABLE_DIFFUSION_URL}/sdapi/v1/txt2img`,
            {
                prompt: prompt,
                width: 512,
                height: 512,
                steps: 50,
            }
        );

        res.json({ image: response.data.images[0] });
    } catch (error) {
        console.error("Error generating avatar:", error);
        res.status(500).json({ error: "Failed to generate avatar" });
    }
});

app.listen(5000, () => {
    console.log('Server running on http://localhost:5000');
});
