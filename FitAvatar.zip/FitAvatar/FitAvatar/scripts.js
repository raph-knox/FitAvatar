document.getElementById("contactForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent actual form submission

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const subject = document.getElementById("subject").value.trim();
    const message = document.getElementById("message").value.trim();
    const msgSubmit = document.getElementById("msgSubmit");

    // Check if the form is valid using the browser's built-in validation
    if (!this.checkValidity()) {
        msgSubmit.style.display = "block";
        msgSubmit.innerText = "Did you fill the form properly?";
        msgSubmit.style.color = "red";
        return; // Stop execution if form is invalid
    }

    // If form is valid, show success message
    msgSubmit.style.display = "block";
    msgSubmit.innerText = "Message sent successfully! We will get back to you via your email as soon as possible. Have a Great Day!";
    msgSubmit.style.color = "green";

    // Reset the form after a delay (optional)
    setTimeout(() => {
        document.getElementById("contactForm").reset();
        msgSubmit.style.display = "none"; // Hide message after reset
    }, 3000);
});